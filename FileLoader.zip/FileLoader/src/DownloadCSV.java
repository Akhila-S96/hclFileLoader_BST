	import java.io.BufferedInputStream;
	import java.io.BufferedOutputStream;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.OutputStream;
import java.util.Arrays;
import java.util.Vector;

import com.jcraft.jsch.Channel;
	import com.jcraft.jsch.ChannelSftp;
	import com.jcraft.jsch.JSch;
	import com.jcraft.jsch.JSchException;
	import com.jcraft.jsch.Session;


public class DownloadCSV {
	
	private String host;
	private Integer port;
	private String user;
	private String password;
	
	private JSch jsch;
	private Session session;
	private Channel channel;
	private ChannelSftp sftpChannel;
	
	
	public void download(ConnectSFTP ftp, String fileName, String localDir) {

		byte[] buffer = new byte[1024];
		BufferedInputStream bis;
		ftp.connect();
		try {
			// Change to output directory
			String cdDir = fileName.substring(0, fileName.lastIndexOf("/") + 1);
			sftpChannel.cd(cdDir);
			Vector<ChannelSftp.LsEntry> remoteFilelist = sftpChannel.ls("*.csv");
			for(ChannelSftp.LsEntry entry : remoteFilelist) {

				File file = new File(entry.getFilename());
				bis = new BufferedInputStream(sftpChannel.get(file.getName()));
				//Creating a File object for directory
			    File localDirectoryPath = new File(localDir);
				String[] localFileList = localDirectoryPath.list();
				Arrays.sort(localFileList);
				if(Arrays.binarySearch(localFileList,file.getName()) == -1) {
					File newFile = new File(localDir + "/" + file.getName());
		
					// Download file
					OutputStream os = new FileOutputStream(newFile);
					BufferedOutputStream bos = new BufferedOutputStream(os);
					int readCount;
					while ((readCount = bis.read(buffer)) > 0) {
						bos.write(buffer, 0, readCount);
					}
					bis.close();
					bos.close();
					System.out.println("File downloaded successfully - "+ file.getAbsolutePath());
					ParseCSVToDBtable csvTodb = new ParseCSVToDBtable(newFile);
					System.out.println(csvTodb.rowsCount + "rows inserted to database"); 
				}
				else System.out.println("File Exists "+ file.getAbsolutePath());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		ftp.disconnect();
	}


	public static void main(String[] args) {
		ConnectSFTP ftp = new ConnectSFTP("10.100.12.14", 2222, "xyz", "password");
		DownloadCSV csv = new DownloadCSV();
		// TODO Auto-generated method stub
		String localPath = "C:/temp/";
		String remotePath = "/export/home/akhila/";
		
		csv.download(ftp,remotePath, localPath);

		
	}

}
