import java.io.*;
import java.math.BigInteger;
import java.sql.*;
public class ParseCSVToDBtable {
	int rowsCount = 0;
	public ParseCSVToDBtable(File csvFile) {
		Connection connection = this.connectToDB("jdbc:mysql://localhost:3306/sales","user","password");
        try {
        	if(connection != null) {
				connection.setAutoCommit(false);
        		int batchSize = 200;
        		String sql = "INSERT INTO review (Result_Time,Granularity_Period, Object_Name, Cell_ID, CallAttemps) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement statement = connection.prepareStatement(sql);
				BufferedReader lineReader = new BufferedReader(new FileReader(csvFile));
	            String lineText = null;
	            
	            int count = 0;
	 
				lineReader.readLine(); // skip header line
	 
	            while ((lineText = lineReader.readLine()) != null) {
	                String[] data = lineText.split(",");
	                String Result_Time = data[0];
	                String Granularity_Period = data[1];
	                String Object_Name = data[2];
	                String Cell_ID = data[3];
	                String CallAttemps = data[4];
	                
	                statement.setString(1, Result_Time);
	                
	                int iGranularity_Period = Integer.parseInt(Granularity_Period);
	                statement.setInt(2, iGranularity_Period);
	 
	                statement.setString(3, Object_Name);
	 
	                long iCell_ID = Integer.parseInt(Cell_ID);
	                statement.setLong(4, iCell_ID);
	 
	                int iCallAttemps = Integer.parseInt(CallAttemps);
	                statement.setInt(5, iCallAttemps);
	 
	                statement.addBatch();
	 
	                if (count % batchSize == 0) {
	                    statement.executeBatch();
	    	            this.rowsCount = this.rowsCount + count; 

	                }
	            }
	            lineReader.close();
        	}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try{
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
		}
        catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public Connection connectToDB(String jdbcURL,String username,String password) {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(jdbcURL, username, password);
			return connection;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return connection;

		}
	}

}
