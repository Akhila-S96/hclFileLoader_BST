/*package whatever //do not write package name here */

import java.io.*;
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;

class BST {
    int[] inputArray;
    Node root = null; 
    
    class Node{
        int data;
        Node left,right;
        
        Node(int value){
            this.data = value;
            this.left = null;
            this.right = null;
        }
        
    }
    public void traverseLeaves(Node root){
        Stack<Node> ele = new Stack<Node>();
        System.out.println("Traverse Leaves");

        ele.push(root);
        while(!ele.isEmpty()){
            Node rootTemp = ele.pop();
            
            //decreasing order
            if(rootTemp.left != null)
                ele.push(rootTemp.left);
            if(rootTemp.right != null)
                ele.push(rootTemp.right);
            else if(rootTemp.left == null && rootTemp.right == null){
                System.out.println(rootTemp.data);
            }
        }
    }
    
    public void printLevelOrder(Node root){
        Queue<Node> leaves = new LinkedList<Node>(); 
        System.out.println("Level Order");
        leaves.add(root);
        while(!leaves.isEmpty()){
            Node rootTemp = leaves.poll();
            System.out.println(rootTemp.data);
    
            if(rootTemp.left != null)
                leaves.add(rootTemp.left);
            if(rootTemp.right != null)
                leaves.add(rootTemp.right);
            
            
        }
    }
    public void insert(Node root,int data){
    
        if(data < root.data){
            if(root.left == null)
                root.left = new Node(data);
            else 
                insert(root.left,data);
        }
        else if(data > root.data){
            if(root.right == null)
                root.right = new Node(data);
            else 
                insert(root.right,data);
        }
    }
    
    public int[] readInputArray(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter no. of elements you want in array:");
        int n = scan.nextInt();
        int a[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n; i++)
        {
            a[i] = scan.nextInt();
        }
        System.out.println("Enter Root element in the array:");
        int rootEle = scan.nextInt();
        this.root = new Node(rootEle);
        return a;
    }
    
	public static void main (String[] args) {
        BST tree = new BST();
        tree.inputArray = tree.readInputArray();
        for(int i:tree.inputArray){
            tree.insert(tree.root,i);
        }
        //traversal of leaves from right to left. 
        tree.traverseLeaves(tree.root);
        //print the breadth first order traversal of this tree
        tree.printLevelOrder(tree.root);

	}
}